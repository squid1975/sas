<?php

require_once('../../private/initialize.php');

$page_title = 'Delete'; 
include(SHARED_PATH . '/salamander-header.php');
?>

<h1>Stub for Delete Salamander</h1>

<?php include(SHARED_PATH . '/salamander-footer.php'); ?>

