<?php
    define("DB_SERVER", 'localhost');
    define("DB_USER", 'sally');
    define("DB_PASS", 'P@ssword1234');
    define("DB_NAME", 'salamanders');
?>